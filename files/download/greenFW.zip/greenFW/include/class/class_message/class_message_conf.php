<?php

define("UNREAD","0");
define("READ","1");

define("GUESTBOOK","Guestbook");

?>