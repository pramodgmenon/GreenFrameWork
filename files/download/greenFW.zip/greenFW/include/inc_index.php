<table style="width:100%; padding:10px; ">
  <tbody>
    <tr>
      <td><?= $index_content; ?></td>
    </tr>
  </tbody>
</table>