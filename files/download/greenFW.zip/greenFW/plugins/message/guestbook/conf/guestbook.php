<?php

$MSG_empty_name = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'MSG_empty_name','guestbook',"Name Empty ","Message on Empty Name");

$MSG_empty_emailid = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'MSG_empty_emailid','guestbook',"Emailid Empty ","Message on Empty Emailid");

$MSG_empty_subject = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'MSG_empty_subject','guestbook',"Subject Empty ","Message on Empty Subject");

$MSG_empty_content = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'MSG_empty_content','guestbook',"Content Empty","Message on Empty Content");

$RD_MSG_error  = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'RD_MSG_error','guestbook',"Some Error Has Been Occurred","Message on Error");

$RD_MSG_msgadded  = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'RD_MSG_msgadded','guestbook',"Message Added","Message on msgadded");

$CAP_page_caption = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_page_caption','guestbook',"G&nbsp;u&nbsp;e&nbsp;s&nbsp;t&nbsp;&nbsp;&nbsp;B&nbsp;o&nbsp;o&nbsp;k","caption page");

$CAP_name = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_name','guestbook',"Name","caption name");

$CAP_address = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_address','guestbook',"Address","caption address");

$CAP_phone = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_phone','guestbook',"Phone","caption phone");

$CAP_emailid = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_emailid','guestbook',"Emailid","caption emailid");

$CAP_subject = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_subject','guestbook',"Subject","caption subject");

$CAP_content = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_content','guestbook',"Content","caption content");

$CAP_submit = $this->gsconf->get_conf(CONF_TYPE_OBJECT_CAPTIONS,'CAP_submit','guestbook',"Submit","caption submit");

?>