<?php

define("DOWNLOAD_DIR","files/download/");
$conf_page_caption = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'conf_page_caption',"download","D&nbsp;o&nbsp;w&nbsp;n&nbsp;l&nbsp;o&nbsp;a&nbsp;d&nbsp; &nbsp;E&nbsp;r&nbsp;r&nbsp;o&nbsp;r","caption page");


?>