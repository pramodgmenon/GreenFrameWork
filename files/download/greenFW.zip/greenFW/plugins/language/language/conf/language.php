<?php

$RD_MSG_lan_deleted = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'RD_MSG_lan_deleted','language',"Language deleted ","Message on language deletion");

$RD_MSG_lan_added = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'RD_MSG_que_added','language',"Language Added ","Message on language Insertion");

$RD_MSG_lan_updated = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'RD_MSG_que_updated','language',"Language Updated ","Message on language updation");

$RD_MSG_on_fail = $this->gsconf->get_conf(CONF_TYPE_MESSAGES,'RD_MSG_on_fail','language',"Your attempt failed.Contact Admin","Message on Failure");

$MSG_empty_language = $this->gsconf->get_conf(CONF_TYPE_OBJECT_CAPTIONS,'MSG_empty_language','language',"Language Empty ","Message on Empty language");

$CAP_page_caption_add = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_page_caption_add','language',"A&nbsp;d&nbsp;d&nbsp;&nbsp;L&nbsp;a&nbsp;n&nbsp;g&nbsp;u&nbsp;a&nbsp;g&nbsp;e","caption language add");

$CAP_page_caption_edit = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_page_caption_edit','language',"E&nbsp;d&nbsp;i&nbsp;t&nbsp;&nbsp;L&nbsp;a&nbsp;n&nbsp;g&nbsp;u&nbsp;a&nbsp;g&nbsp;e","caption language edit");

$CAP_language = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_language','language',"Language","caption language");

$CAP_publish = $this->gsconf->get_conf(CONF_TYPE_CAPTIONS,'CAP_publish','language',"Publish","caption publish");

$CAP_insert = $this->gsconf->get_conf(CONF_TYPE_OBJECT_CAPTIONS,'CAP_insert','language',"Update","caption insert");

$CAP_update = $this->gsconf->get_conf(CONF_TYPE_OBJECT_CAPTIONS,'CAP_update','language',"Update","caption update");

$CAP_delete = $this->gsconf->get_conf(CONF_TYPE_OBJECT_CAPTIONS,'CAP_delete','language',"Delete","caption delete");

?>